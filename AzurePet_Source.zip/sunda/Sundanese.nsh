;Language: Sundanese (1089)
;Basa Sunda sapopoé (loma/gaul) pikeun installer AzurePet.
;String nu teu aya di dieu otomatis dicokot tina basa Inggris (English.nsh).

!insertmacro LANGFILE "Sundanese" = "Basa Sunda" =

!ifdef MUI_WELCOMEPAGE
  ${LangFileString} MUI_TEXT_WELCOME_INFO_TITLE "Sampurasun! Ieu mah instalasi $(^NameDA)"
  ${LangFileString} MUI_TEXT_WELCOME_INFO_TEXT "Ieu bakal mantuan manéh masang $(^NameDA).$\r$\n$\r$\nSok we tutup heula aplikasi séjénna saméméh nuluykeun, sangkan file-file nu aya patalina bisa diropéa tanpa kudu ngamuat ulang komputer.$\r$\n$\r$\n$_CLICK"
!endif

!ifdef MUI_UNWELCOMEPAGE
  ${LangFileString} MUI_UNTEXT_WELCOME_INFO_TITLE "Sampurasun! Ieu mah miceun $(^NameDA)"
  ${LangFileString} MUI_UNTEXT_WELCOME_INFO_TEXT "Ieu bakal mantuan manéh miceun $(^NameDA).$\r$\n$\r$\nSaméméh nuluykeun, pastikeun $(^NameDA) geus teu dianggo.$\r$\n$\r$\n$_CLICK"
!endif

!ifdef MUI_LICENSEPAGE
  ${LangFileString} MUI_TEXT_LICENSE_TITLE "Ngeunaan Lisensi"
  ${LangFileString} MUI_TEXT_LICENSE_SUBTITLE "Baca heula lisensina saméméh masang $(^NameDA), nya."
  ${LangFileString} MUI_INNERTEXT_LICENSE_BOTTOM "Mun manéh satuju kana sadaya eusina, pencét Satuju pikeun nuluykeun. Kudu satuju heula sangkan bisa masang $(^NameDA)."
  ${LangFileString} MUI_INNERTEXT_LICENSE_BOTTOM_CHECKBOX "Mun manéh satuju kana sadaya eusina, pasihan centang di handap. Kudu satuju heula sangkan bisa masang $(^NameDA). $_CLICK"
  ${LangFileString} MUI_INNERTEXT_LICENSE_BOTTOM_RADIOBUTTONS "Mun manéh satuju kana sadaya eusina, pilih salah sahiji di handap. Kudu satuju heula sangkan bisa masang $(^NameDA). $_CLICK"
!endif

!ifdef MUI_UNLICENSEPAGE
  ${LangFileString} MUI_UNTEXT_LICENSE_TITLE "Ngeunaan Lisensi"
  ${LangFileString} MUI_UNTEXT_LICENSE_SUBTITLE "Baca heula lisensina saméméh miceun $(^NameDA), nya."
  ${LangFileString} MUI_UNINNERTEXT_LICENSE_BOTTOM "Mun manéh satuju kana sadaya eusina, pencét Satuju pikeun nuluykeun. Kudu satuju heula sangkan bisa miceun $(^NameDA)."
  ${LangFileString} MUI_UNINNERTEXT_LICENSE_BOTTOM_CHECKBOX "Mun manéh satuju kana sadaya eusina, pasihan centang. Kudu satuju heula sangkan bisa miceun $(^NameDA). $_CLICK"
  ${LangFileString} MUI_UNINNERTEXT_LICENSE_BOTTOM_RADIOBUTTONS "Mun manéh satuju kana sadaya eusina, pilih salah sahiji di handap. Kudu satuju heula sangkan bisa miceun $(^NameDA). $_CLICK"
!endif

!ifdef MUI_LICENSEPAGE | MUI_UNLICENSEPAGE
  ${LangFileString} MUI_INNERTEXT_LICENSE_TOP "Pencét Page Down mun hayang maca salajengna."
!endif

!ifdef MUI_DIRECTORYPAGE
  ${LangFileString} MUI_TEXT_DIRECTORY_TITLE "Milih Lokasi Instalasi"
  ${LangFileString} MUI_TEXT_DIRECTORY_SUBTITLE "Pilih rék dipasangna di mana $(^NameDA)."
!endif

!ifdef MUI_UNDIRECTORYPAGE
  ${LangFileString} MUI_UNTEXT_DIRECTORY_TITLE "Milih Lokasi nu rék Dipiceun"
  ${LangFileString} MUI_UNTEXT_DIRECTORY_SUBTITLE "Pilih lokasi instalasi $(^NameDA) nu rék dipiceun."
!endif

!ifdef MUI_INSTFILESPAGE
  ${LangFileString} MUI_TEXT_INSTALLING_TITLE "Keur masang"
  ${LangFileString} MUI_TEXT_INSTALLING_SUBTITLE "Sakedap deui, $(^NameDA) keur dipasang..."
  ${LangFileString} MUI_TEXT_FINISH_TITLE "Geus Beres!"
  ${LangFileString} MUI_TEXT_FINISH_SUBTITLE "Réngsé kabéh, euy."
  ${LangFileString} MUI_TEXT_ABORT_TITLE "Instalasi Dibolaykeun"
  ${LangFileString} MUI_TEXT_ABORT_SUBTITLE "Wah, instalasina teu beres."
!endif

!ifdef MUI_UNINSTFILESPAGE
  ${LangFileString} MUI_UNTEXT_UNINSTALLING_TITLE "Keur miceun"
  ${LangFileString} MUI_UNTEXT_UNINSTALLING_SUBTITLE "Sakedap deui, $(^NameDA) keur dipiceun..."
  ${LangFileString} MUI_UNTEXT_FINISH_TITLE "Geus Dibersihkeun"
  ${LangFileString} MUI_UNTEXT_FINISH_SUBTITLE "Réngsé kabéh, euy."
  ${LangFileString} MUI_UNTEXT_ABORT_TITLE "Piceun Dibolaykeun"
  ${LangFileString} MUI_UNTEXT_ABORT_SUBTITLE "Wah, mariceunna teu beres."
!endif

!ifdef MUI_FINISHPAGE
  ${LangFileString} MUI_TEXT_FINISH_INFO_TITLE "Beres! Instalasi $(^NameDA)"
  ${LangFileString} MUI_TEXT_FINISH_INFO_TEXT "$(^NameDA) geus dianggo di komputer manéh.$\r$\n$\r$\nPencét Réngsé pikeun nutup ieu jandéla."
  ${LangFileString} MUI_TEXT_FINISH_INFO_REBOOT "Komputerna kudu di-restart heula sangkan instalasi $(^NameDA) bener-bener beres. Ayeuna waé?"
!endif

!ifdef MUI_UNFINISHPAGE
  ${LangFileString} MUI_UNTEXT_FINISH_INFO_TITLE "Beres! Piceun $(^NameDA)"
  ${LangFileString} MUI_UNTEXT_FINISH_INFO_TEXT "$(^NameDA) geus dipiceun tina komputer manéh.$\r$\n$\r$\nPencét Réngsé pikeun nutup ieu jandéla."
  ${LangFileString} MUI_UNTEXT_FINISH_INFO_REBOOT "Komputerna kudu di-restart heula sangkan piceun $(^NameDA) bener-bener beres. Ayeuna waé?"
!endif

!ifdef MUI_FINISHPAGE | MUI_UNFINISHPAGE
  ${LangFileString} MUI_TEXT_FINISH_REBOOTNOW "Restart ayeuna"
  ${LangFileString} MUI_TEXT_FINISH_REBOOTLATER "Restart engké"
  ${LangFileString} MUI_TEXT_FINISH_RUN "&Buka $(^NameDA)"
  ${LangFileString} MUI_TEXT_FINISH_SHOWREADME "&Buka file Readme"
  ${LangFileString} MUI_BUTTONTEXT_FINISH "&Réngsé"
!endif

!ifdef MUI_STARTMENUPAGE
  ${LangFileString} MUI_TEXT_STARTMENU_TITLE "Milih tempat di Ménu Start"
  ${LangFileString} MUI_TEXT_STARTMENU_SUBTITLE "Pilih tempat shortcut $(^NameDA) dina Ménu Start."
  ${LangFileString} MUI_INNERTEXT_STARTMENU_TOP "Pilih tempat shortcut ieu program dina Ménu Start. Bisa ogé nyieun tempat anyar ku cara ngetik ngaranna."
  ${LangFileString} MUI_INNERTEXT_STARTMENU_CHECKBOX "Teu kudu nyieun shortcut"
!endif

!ifdef MUI_UNCONFIRMPAGE
  ${LangFileString} MUI_UNTEXT_CONFIRM_TITLE "Piceun $(^NameDA)"
  ${LangFileString} MUI_UNTEXT_CONFIRM_SUBTITLE "Miceun $(^NameDA) tina komputer manéh."
!endif

!ifdef MUI_ABORTWARNING
  ${LangFileString} MUI_TEXT_ABORTWARNING "Geus yakin rék ngabolaykeun instalasi $(^Name)?"
!endif

!ifdef MUI_UNABORTWARNING
  ${LangFileString} MUI_UNTEXT_ABORTWARNING "Geus yakin rék ngabolaykeun piceun $(^Name)?"
!endif
