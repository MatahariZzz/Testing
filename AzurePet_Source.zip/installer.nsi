Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "WinVer.nsh"
!define APP "AzurePet"
!define VER "1.12.0"
!define UNKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APP}"
!define SU_ID 1089   ; ID basa Sunda (aya dina sunda\Sundanese.nlf)

Name "${APP}"
OutFile "AzurePet-Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\${APP}"
RequestExecutionLevel user
SetCompressor /SOLID lzma
SetCompressorDictSize 64
BrandingText "${APP} ${VER}"
VIProductVersion "${VER}.0"
VIAddVersionKey "ProductName" "${APP}"
VIAddVersionKey "FileDescription" "${APP} Installer"
VIAddVersionKey "FileVersion" "${VER}"
VIAddVersionKey "ProductVersion" "${VER}"
VIAddVersionKey "LegalCopyright" "${APP}"

!define MUI_ICON "icon.ico"
!define MUI_UNICON "icon.ico"
!define MUI_ABORTWARNING
!define MUI_BGCOLOR "FFE6EE"
!define MUI_TEXTCOLOR "5B2B3F"
!define MUI_INSTFILESPAGE_COLORS "5B2B3F FFF6F9"
!define MUI_INSTFILESPAGE_PROGRESSBAR "colored"
!define MUI_WELCOMEFINISHPAGE_BITMAP "kiri.bmp"

; ---------- bahasa: tanya dulu, lalu semua halaman ikut bahasa itu ----------
!define MUI_LANGDLL_ALWAYSSHOW
!define MUI_LANGDLL_WINDOWTITLE "Bahasa / Language / Basa"
!define MUI_LANGDLL_INFO "Pilih bahasa installer.$\r$\nChoose the installer language.$\r$\nPilih basa installer."
!define MUI_LANGDLL_REGISTRY_ROOT "HKCU"
!define MUI_LANGDLL_REGISTRY_KEY "Software\${APP}"
!define MUI_LANGDLL_REGISTRY_VALUENAME "Bahasa"

!define MUI_WELCOMEPAGE_TITLE_3LINES
!define MUI_WELCOMEPAGE_TEXT "$(TXT_WELCOME)"
!define MUI_FINISHPAGE_RUN "$INSTDIR\${APP}.exe"
!define MUI_FINISHPAGE_RUN_TEXT "$(TXT_RUN)"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "Indonesian"
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGEEX "${__FILEDIR__}\sunda" "Sundanese"

; ---------- teks sendiri per bahasa ----------
LangString TXT_WELCOME ${LANG_INDONESIAN} "Installer ini akan memasang ${APP} di komputer kamu.$\r$\n$\r$\n${APP} menampilkan karakter 3D (.glb) yang berjalan-jalan di desktop.$\r$\n$\r$\nYang akan dibuat:$\r$\n  •  Shortcut di Desktop$\r$\n  •  Shortcut di Start Menu (bisa dicari lewat Search Windows)$\r$\n  •  Uninstaller di Settings > Apps$\r$\n$\r$\nKlik Install untuk melanjutkan."
LangString TXT_WELCOME ${LANG_ENGLISH} "This installer will set up ${APP} on your computer.$\r$\n$\r$\n${APP} shows 3D characters (.glb) that walk around your desktop.$\r$\n$\r$\nIt will create:$\r$\n  •  A Desktop shortcut$\r$\n  •  A Start Menu shortcut (findable in Windows Search)$\r$\n  •  An uninstaller in Settings > Apps$\r$\n$\r$\nClick Install to continue."
LangString TXT_WELCOME ${SU_ID} "Ieu installer bakal masang ${APP} dina komputer manéh.$\r$\n$\r$\n${APP} mah némbongkeun karakter 3D (.glb) nu leumpang-léumpang dina desktop.$\r$\n$\r$\nNu bakal dijieun:$\r$\n  •  Shortcut dina Desktop$\r$\n  •  Shortcut dina Ménu Start (bisa dipilari dina Search Windows)$\r$\n  •  Uninstaller dina Settings > Apps$\r$\n$\r$\nKlik Instal, geura pasang."

LangString TXT_RUN ${LANG_INDONESIAN} "Jalankan ${APP} sekarang"
LangString TXT_RUN ${LANG_ENGLISH} "Run ${APP} now"
LangString TXT_RUN ${SU_ID} "Buka ${APP} ayeuna"

LangString TXT_WIN10 ${LANG_INDONESIAN} "${APP} membutuhkan Windows 10 atau Windows 11."
LangString TXT_WIN10 ${LANG_ENGLISH} "${APP} needs Windows 10 or Windows 11."
LangString TXT_WIN10 ${SU_ID} "Punten, ${APP} mah butuh Windows 10 atawa Windows 11."

; kode basa (id/en/su) nu dibaca aplikasi nalika mimiti dijalankeun
LangString TXT_KODE ${LANG_INDONESIAN} "id"
LangString TXT_KODE ${LANG_ENGLISH} "en"
LangString TXT_KODE ${SU_ID} "su"

!macro KillApp
  nsExec::Exec 'taskkill /F /T /IM "${APP}.exe"'
  Pop $0
  Sleep 800
!macroend

; simpen pilihan basa installer supaya aplikasi langsung make basa nu sarua
!macro SimpanBahasa
  CreateDirectory "$APPDATA\${APP}"
  FileOpen $9 "$APPDATA\${APP}\bahasa.txt" w
  FileWrite $9 "$(TXT_KODE)"
  FileClose $9
!macroend

Function .onInit
  !insertmacro MUI_LANGDLL_DISPLAY
  ${IfNot} ${AtLeastWin10}
    MessageBox MB_OK|MB_ICONSTOP "$(TXT_WIN10)" /SD IDOK
    Abort
  ${EndIf}
FunctionEnd

Section "Install"
  SetShellVarContext current
  !insertmacro KillApp
  ; ---- upgrade from the old name (DesktopPet): keep settings, remove old app ----
  nsExec::Exec 'taskkill /F /T /IM "DesktopPet.exe"'
  Pop $0
  IfFileExists "$APPDATA\${APP}\config.json" oldcfg_done 0
  IfFileExists "$APPDATA\DesktopPet\config.json" 0 oldcfg_done
    CreateDirectory "$APPDATA\${APP}"
    CopyFiles /SILENT "$APPDATA\DesktopPet\config.json" "$APPDATA\${APP}\config.json"
  oldcfg_done:
  IfFileExists "$LOCALAPPDATA\Programs\DesktopPet\Uninstall.exe" 0 old_done
    ExecWait '"$LOCALAPPDATA\Programs\DesktopPet\Uninstall.exe" /S _?=$LOCALAPPDATA\Programs\DesktopPet'
    RMDir /r "$LOCALAPPDATA\Programs\DesktopPet"
  old_done:
  !insertmacro SimpanBahasa
  RMDir /r "$INSTDIR\resources"
  SetOutPath "$INSTDIR"
  File /r "win\*.*"
  File "icon.ico"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateShortCut "$DESKTOP\${APP}.lnk" "$INSTDIR\${APP}.exe" "" "$INSTDIR\icon.ico" 0
  CreateDirectory "$SMPROGRAMS\${APP}"
  CreateShortCut "$SMPROGRAMS\${APP}\${APP}.lnk" "$INSTDIR\${APP}.exe" "" "$INSTDIR\icon.ico" 0
  CreateShortCut "$SMPROGRAMS\${APP}\Uninstall ${APP}.lnk" "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "${UNKEY}" "DisplayName" "${APP}"
  WriteRegStr HKCU "${UNKEY}" "DisplayVersion" "${VER}"
  WriteRegStr HKCU "${UNKEY}" "Publisher" "${APP}"
  WriteRegStr HKCU "${UNKEY}" "DisplayIcon" "$INSTDIR\icon.ico"
  WriteRegStr HKCU "${UNKEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNKEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKCU "${UNKEY}" "QuietUninstallString" '"$INSTDIR\Uninstall.exe" /S'
  WriteRegDWORD HKCU "${UNKEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNKEY}" "NoRepair" 1
  WriteRegDWORD HKCU "${UNKEY}" "EstimatedSize" 215000
SectionEnd

Section "Uninstall"
  SetShellVarContext current
  !insertmacro KillApp
  Delete "$DESKTOP\${APP}.lnk"
  RMDir /r "$SMPROGRAMS\${APP}"
  DeleteRegKey HKCU "${UNKEY}"
  DeleteRegKey HKCU "Software\${APP}"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${APP}"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "electron.app.${APP}"
  ; only remove the folder if it really is our install folder
  IfFileExists "$INSTDIR\${APP}.exe" 0 +2
    RMDir /r "$INSTDIR"
  RMDir /r "$APPDATA\${APP}"
SectionEnd
