/* AzurePet - kamus bahasa (Indonesia / English / Basa Sunda)
   Dipakai proses utama lewat require('./bahasa.js') dan jendela pengaturan
   lewat <script src="bahasa.js">. Tidak ada dependensi, aman dipakai di keduanya. */
(function (root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window !== 'undefined') window.Bahasa = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var DAFTAR = ['id', 'en', 'su'];               // urutan tampil di pemilih bahasa
  var NAMA = { id: 'Bahasa Indonesia', en: 'English', su: 'Basa Sunda' };

  var TEKS = {
    id: {
      /* ---------- proses utama: tray, menu, dialog, status ---------- */
      judulSetelan: 'AzurePet - Pengaturan',
      traySetelan: 'Pengaturan',
      traySembunyi: 'Sembunyikan semua karakter',
      trayTampil: 'Tampilkan semua karakter',
      trayKeluar: 'Keluar',
      menuAtur: 'Atur karakter ini',
      menuHapus: 'Hapus karakter ini',
      pesanMaksimal: 'Maksimal {n} karakter sekaligus.',
      pilihModelJudul: 'Pilih model 3D (.glb)',
      pilihModelFilter: 'Model 3D',
      stMemuat: 'Memuat model...',
      stTidakAda: 'Gagal: file tidak ditemukan ({path})',
      stGagalBaca: 'Gagal membaca file: {err}',
      stGagalModel: 'Gagal memuat model: {err}',
      stAnimasi: '{n} animasi',
      stGagalSingkat: 'gagal',
      stProsesSingkat: 'memuat...',
      autostartKomentar: 'Karakter 3D di desktop',

      /* ---------- jendela pengaturan ---------- */
      sub: 'Karakter 3D yang jalan-jalan di desktop kamu — bisa banyak sekaligus',
      k1: '1. Daftar karakter',
      k2: '2. Animasi',
      k3: '3. Gerakan karakter ini',
      tambah: '+ Tambah karakter (.glb)...',
      hintTambah: 'Bisa pilih beberapa file sekaligus, atau seret file .glb ke jendela ini.',
      kosong: 'Belum ada karakter. Klik tombol di bawah untuk menambahkan file .glb kamu.',
      diam: 'Saat diam (idle)',
      jalan: 'Saat jalan',
      drag: 'Saat di-drag',
      klik: 'Saat diklik',
      gantiModel: 'Ganti file model',
      gandakan: 'Gandakan karakter',
      ukuran: 'Ukuran',
      kecepatan: 'Kecepatan jalan',
      yaw: 'Putar arah hadap',
      area: 'Area jalan',
      'areaBawah.win': 'Di atas taskbar (bawah layar)',
      'areaBawah.linux': 'Di atas panel (bawah layar)',
      'areaBawah.mac': 'Di atas Dock (bawah layar)',
      areaBebas: 'Bebas ke seluruh layar',
      autoWalk: 'Jalan-jalan otomatis',
      selaluAtas: 'Semua karakter selalu di atas jendela lain',
      'autoStart.win': 'Jalankan otomatis saat Windows menyala',
      'autoStart.linux': 'Jalankan otomatis saat komputer menyala',
      'autoStart.mac': 'Jalankan otomatis saat Mac menyala',
      sembunyiSemua: 'Sembunyikan semua',
      tampilSemua: 'Tampilkan semua',
      keluarApp: 'Keluar aplikasi',
      'tutupHint.win': 'Menutup jendela ini tidak mematikan karakter. Buka lagi lewat ikon di tray (pojok kanan bawah) atau klik kanan karakternya.',
      'tutupHint.linux': 'Menutup jendela ini tidak mematikan karakter. Buka lagi lewat ikon AzurePet di menu aplikasi, ikon di area tray, atau klik kanan karakternya.',
      'tutupHint.mac': 'Menutup jendela ini tidak mematikan karakter. Buka lagi lewat ikon AzurePet di Dock, ikon di menu bar (kanan atas), atau klik kanan karakternya.',
      hapus: 'Hapus',
      tanpaAnimasi: '(tanpa animasi)'
    },

    en: {
      judulSetelan: 'AzurePet - Settings',
      traySetelan: 'Settings',
      traySembunyi: 'Hide all characters',
      trayTampil: 'Show all characters',
      trayKeluar: 'Quit',
      menuAtur: 'Edit this character',
      menuHapus: 'Remove this character',
      pesanMaksimal: 'Up to {n} characters at once.',
      pilihModelJudul: 'Choose a 3D model (.glb)',
      pilihModelFilter: '3D model',
      stMemuat: 'Loading model...',
      stTidakAda: 'Failed: file not found ({path})',
      stGagalBaca: 'Could not read the file: {err}',
      stGagalModel: 'Could not load the model: {err}',
      stAnimasi: '{n} animations',
      stGagalSingkat: 'failed',
      stProsesSingkat: 'loading...',
      autostartKomentar: '3D character on your desktop',

      sub: '3D characters that walk around your desktop — as many as you like',
      k1: '1. Character list',
      k2: '2. Animation',
      k3: "3. This character's movement",
      tambah: '+ Add character (.glb)...',
      hintTambah: 'You can pick several files at once, or drag .glb files into this window.',
      kosong: 'No characters yet. Click the button below to add your own .glb file.',
      diam: 'While idle',
      jalan: 'While walking',
      drag: 'While dragged',
      klik: 'When clicked',
      gantiModel: 'Change model file',
      gandakan: 'Duplicate character',
      ukuran: 'Size',
      kecepatan: 'Walking speed',
      yaw: 'Facing direction',
      area: 'Walking area',
      'areaBawah.win': 'Above the taskbar',
      'areaBawah.linux': 'Above the panel',
      'areaBawah.mac': 'Above the Dock',
      areaBebas: 'Free across the whole screen',
      autoWalk: 'Walk around automatically',
      selaluAtas: 'Keep all characters above other windows',
      'autoStart.win': 'Start automatically when Windows starts',
      'autoStart.linux': 'Start automatically when the computer starts',
      'autoStart.mac': 'Start automatically when the Mac starts',
      sembunyiSemua: 'Hide all',
      tampilSemua: 'Show all',
      keluarApp: 'Quit app',
      'tutupHint.win': 'Closing this window does not stop the characters. Open it again from the tray icon (bottom-right corner) or by right-clicking a character.',
      'tutupHint.linux': 'Closing this window does not stop the characters. Open it again from the AzurePet icon in the app menu, the tray icon, or by right-clicking a character.',
      'tutupHint.mac': 'Closing this window does not stop the characters. Open it again from the AzurePet icon in the Dock, the menu bar icon (top-right), or by right-clicking a character.',
      hapus: 'Remove',
      tanpaAnimasi: '(no animation)'
    },

    su: {
      // basa Sunda sapopoé (loma/gaul), lain basa lemes
      judulSetelan: 'AzurePet - Setélan',
      traySetelan: 'Setélan',
      traySembunyi: 'Sumputkeun karakterna',
      trayTampil: 'Témbongkeun deui karakterna',
      trayKeluar: 'Kaluar',
      menuAtur: 'Setél ieu karakter',
      menuHapus: 'Piceun ieu karakter',
      pesanMaksimal: 'Uih, paling loba {n} karakter sakaligus atuh!',
      pilihModelJudul: 'Milih file modél 3D (.glb)',
      pilihModelFilter: 'Modél 3D',
      stMemuat: 'Keur ngamuat modél...',
      stTidakAda: 'Berkasna teu kapanggih ({path})',
      stGagalBaca: 'Teu bisa maca berkasna: {err}',
      stGagalModel: 'Modélna teu bisa dimuat: {err}',
      stAnimasi: '{n} animasi',
      stGagalSingkat: 'gagal',
      stProsesSingkat: 'keur ngamuat...',
      autostartKomentar: 'Karakter 3D dina desktop',

      sub: 'Karakter 3D nu leumpang-léumpang dina desktop manéh — bisa loba sakaligus',
      k1: '1. Daftar karakterna',
      k2: '2. Animasi',
      k3: '3. Gerakanna',
      tambah: '+ Tambah karakter (.glb)...',
      hintTambah: 'Bisa milih sababaraha file sakaligus, atawa gé séred waé file .glb ka ieu jandéla.',
      kosong: 'Can aya karakter. Klik tombol di handap, tuluy tambahkeun file .glb manéh.',
      diam: 'Cicing (idle)',
      jalan: 'Leumpang',
      drag: 'Digésér',
      klik: 'Diklik',
      gantiModel: 'Ganti file modél',
      gandakan: 'Kopi karakterna',
      ukuran: 'Ukuran',
      kecepatan: 'Laju leumpang',
      yaw: 'Arah nyanghareup',
      area: 'Area leumpang',
      'areaBawah.win': 'Di luhur taskbar (handap layar)',
      'areaBawah.linux': 'Di luhur panel (handap layar)',
      'areaBawah.mac': 'Di luhur Dock (handap layar)',
      areaBebas: 'Bébas ka mana waé',
      autoWalk: 'Leumpang sorangan',
      selaluAtas: 'Karakterna nangkring di luhur jandéla séjén',
      'autoStart.win': 'Jalankeun sorangan mun Windows hurung',
      'autoStart.linux': 'Jalankeun sorangan mun komputer hurung',
      'autoStart.mac': 'Jalankeun sorangan mun Mac hurung',
      sembunyiSemua: 'Sumputkeun kabéh',
      tampilSemua: 'Témbongkeun kabéh',
      keluarApp: 'Kaluar ah',
      'tutupHint.win': 'Nutup ieu jandéla mah karakterna tetep aya. Buka deui tina ikon di tray (pojok katuhu handap) atawa klik-katuhu karakterna.',
      'tutupHint.linux': 'Nutup ieu jandéla mah karakterna tetep aya. Buka deui tina ikon AzurePet dina ménu aplikasi, ikon di tray, atawa klik-katuhu karakterna.',
      'tutupHint.mac': 'Nutup ieu jandéla mah karakterna tetep aya. Buka deui tina ikon AzurePet dina Dock, ikon di menu bar (katuhu luhur), atawa klik-katuhu karakterna.',
      hapus: 'Piceun',
      tanpaAnimasi: '(euweuh animasi)'
    }
  };

  function normalisasi(b) {
    if (typeof b !== 'string') return 'id';
    var k = b.trim().toLowerCase();
    if (DAFTAR.indexOf(k) !== -1) return k;
    if (k.indexOf('in') === 0 || k.indexOf('id') === 0) return 'id'; // "in-ID", "id-ID"
    if (k.indexOf('su') === 0) return 'su';                          // "su-ID", "sun"
    if (k.indexOf('en') === 0) return 'en';
    return 'id';
  }

  // t(bahasa, kunci, {isi}) -> teks; kunci tak dikenal dikembalikan apa adanya
  function t(bahasa, kunci, isi) {
    var d = TEKS[normalisasi(bahasa)];
    var s = d && d[kunci] != null ? d[kunci] : TEKS.id[kunci];
    if (s == null) s = String(kunci);
    if (isi) {
      for (var k in isi) {
        if (Object.prototype.hasOwnProperty.call(isi, k)) {
          s = s.split('{' + k + '}').join(String(isi[k]));
        }
      }
    }
    return s;
  }

  // akhiran platform untuk kunci yang beda istilah per sistem operasi
  function akhiranOS(platform) {
    var p = platform || (typeof process !== 'undefined' && process.platform) || 'win32';
    if (p === 'darwin' || p === 'mac') return 'mac';
    if (p === 'linux') return 'linux';
    return 'win';
  }

  function perOS(bahasa, kunci, platform, isi) {
    return t(bahasa, kunci + '.' + akhiranOS(platform), isi);
  }

  return {
    DAFTAR: DAFTAR,
    NAMA: NAMA,
    TEKS: TEKS,
    normalisasi: normalisasi,
    t: t,
    akhiranOS: akhiranOS,
    perOS: perOS
  };
});
